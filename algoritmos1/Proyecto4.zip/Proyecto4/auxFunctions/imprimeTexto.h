#include <stdio.h>

void imprimeTexto(char* texto){

    printf("%s\n",texto);
}