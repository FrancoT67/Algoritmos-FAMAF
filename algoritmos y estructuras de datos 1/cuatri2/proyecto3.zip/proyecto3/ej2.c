#include <stdio.h>
#include <stdbool.h>

/* Libreria personal para mostrar datos */
#include "./entradasInt.h"

/*
Encontrar los valores para las variables para que las siguientes expresiones tengan el resultado indicado.

(x → 0, y → 0, z →0, b → 0, w→0 )
-----------------------------------------
| Expresion                      | Valor |
-----------------------------------------
| x%4 == 0                       | True  |
| x +y == 0 &&  y - x == (-1) *z | True  |
| not b && w                     | False |
-----------------------------------------
*/

/* Funcion auxiliar */
// La función recibe como parametro una expresion de condicion y verifica si el resultado de su comprobación es 1 (True ) o 0 (False).
char comprobacion(int expresion)
{
    if (expresion == 1)
    {
        return 'T';
    }
    return 'F';
}

int main()
{

    /* Instanciacion de Variables */
    int x = 0;
    int y = 0;
    int z = 0;
    int b = 0;
    int w = 0;
    /* Solicitud de Valores para las variables */
    x = pedirEntero('x');
    x = pedirEntero('y');
    x = pedirEntero('z');
    x = pedirEntero('b');
    x = pedirEntero('w');

    /* Expresiones Solicictadas */
    printf("Resultado de %d (Modulo)4 == 0 es %c\n", x, comprobacion((x % 4 == 0)));
    printf("Resultado de %d + %d == 0 && %d - %d == (-1) * %d es : %c\n", x, y, y, x, z, comprobacion((x + y == 0 && y - x == (-1) * z)));
    printf("Resultado de not %d && %d es: %c\n", b, w, comprobacion((!b && w)));

    return 0;
}
